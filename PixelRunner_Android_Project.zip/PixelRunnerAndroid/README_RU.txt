PIXEL RUNNER — Android-проект для сборки APK

Что внутри:
- app/src/main/assets/index.html — твой исходный HTML-файл игры.
- MainActivity.java — запускает игру в полноэкранном Android WebView.
- AndroidManifest.xml — имя приложения и альбомная ориентация.

Как получить APK:
1. Установи Android Studio на компьютер.
2. Распакуй архив PixelRunner_Android_Project.zip.
3. В Android Studio выбери Open и открой папку PixelRunnerAndroid.
4. Дождись окончания Gradle Sync. При первом запуске Android Studio может скачать Android Gradle Plugin и Android SDK Platform 35.
5. Выбери Build → Build Bundle(s) / APK(s) → Build APK(s).
6. После успешной сборки нажми Locate в уведомлении.
   APK обычно находится в app/build/outputs/apk/debug/app-debug.apk.

Важно:
- Это готовый Android Studio проект, а не уже собранный APK.
- В этой среде нет Android SDK/Gradle, поэтому я не могу честно приложить готовый APK.
- Игра загружается из assets и рассчитана на автономную работу.
- Прогресс сохраняется через localStorage WebView на этом устройстве.
